import java.awt.event.KeyEvent;
import java.awt.Color;


//Abstract parent Game class - contains general game properties and acts as the 
//"framework" of our game engine, more specifc methods/attributes go in children 
public abstract class GameCore {
    
    
    
    //---------------- Class Variables and Constants -----------------//
    
    
    //The initial timer delay -- the number of milliseconds between each
    //"tick" in the game loop.  See play() and sleep() for more info.
    protected static final int DEFAULT_TIMER_DELAY = 100;
    protected static final int MIN_TIMER_DELAY = 20;
    
    //default color for grid lines to be drawn between cells:
    private static final Color DEFAULT_GRID_LINES_COLOR= Color.BLACK;
    
    //the keyboard key used to advance past a splash screen
    private static final int KEY_DEFAULT_ADVANCE_SPLASH_SCREEN = KeyEvent.VK_ENTER;
    
    //initial value for factor (see "factor" instance variable below
    private static final int STARTING_FACTOR = 3;
    
    //---------------- Instance Variables -----------------//
    
    //The grid that represents our game "board" (i.e. the window that the game
    //is rendered in) -- essentially a matrix of cells (see GameGrid code)
    private GameGrid grid;
    
    //Game clock -- milliseconds elapsed since game started (see play()) 
    protected long msElapsed;  
    
    //tracks total number of "ticks" since game started (see play())
    protected int ticksElapsed; 
    
    //Controls game speed (ms between game "ticks"); retain a default in case we speed up/slow down game
    protected int currentTimerDelay;  
    protected int defaultTimerDelay;
    
    //determines how frequently (ie. once every "factor" number of game ticks)
    //the game board is updated, meaning redrawn or repainted.
    protected int factor = STARTING_FACTOR;
    
    //determines if the game is paused or not
    protected boolean isPaused;
    
    
    
    //---------------- Constructor -----------------//
    
    //arguments provided by child class, no background image (see 4 arg constructor)
    public GameCore(int hdim, int wdim, int timerDelay) {
        this(hdim, wdim, timerDelay, null);
    }
    
    
    //Initializes general grid properties    
    //hdim/wdim: determines number of rows/columns on board, respectively    
    //backgroundImg: filename of image to be used as background for the game window
    //calls init to initialize timing properties.
    public GameCore(int hdim, int wdim, int timerDelay, String backgroundImg) {
        //initialize grid
        this.grid = new GameGrid(hdim, wdim, backgroundImg);
        
        init(timerDelay);
        
    }    
    
    
    //Initializes attributes, counters, and timers
    //timerDelay: determines initial speed of game -- time between "ticks" (see game loop code for more)        
    private void init(int timerDelay){
        //Initialize attributes and counters
        this.currentTimerDelay = timerDelay;
        this.defaultTimerDelay = timerDelay;
        this.ticksElapsed = 0;
        this.msElapsed = 0;        
        
        this.isPaused = false;        
        
    }
    
    
    
    //---------------- Instance Methods -----------------//
    
    //Runs the game, including pre and post game tasks
    public void run(){     
        startGame(); 
        gameLoop();  
        endGame();   
    }
    
    
    //-------------------- Reset & Timing Methods ------------------------//
    
    //increases the time between 'ticks' by a specified amount
    protected void slowDown(int msDelay){
        currentTimerDelay += msDelay;
    }
    
    
    //decreases the time between 'ticks' by a specified amount
    protected void speedUp(int msDelay){
        System.out.println("BEFORE delay " + currentTimerDelay + " " + msDelay);
        
        currentTimerDelay = Math.max(currentTimerDelay - msDelay, MIN_TIMER_DELAY);
        System.out.println("delay " + currentTimerDelay);
    }
    
    //resets time between 'ticks' to the default value
    protected void resetSpeed() {
        currentTimerDelay = defaultTimerDelay;
    }    
    
    
    //-------------------- Display/Hide Game Methods ---------------------//
    
    
    //displays a still 'splash' screen, that is drawn over the game window
    //until the user presses the default splash screen advancement key
    protected void displayStillScreen(String screen){
        runStillScreen(screen, KEY_DEFAULT_ADVANCE_SPLASH_SCREEN);
    }
    
    //displays a still 'splash' screen, that is drawn over the game window
    //until the user presses the argument advancement key
    protected void displayStillScreen(String screen, int advanceKey){
        runStillScreen(screen, advanceKey);
    }
    
    // Turn on grid lines using default color (useful for debugging)
    protected void displayGridLines(){
        displayGridLines(DEFAULT_GRID_LINES_COLOR);
        grid.setLineColor(Color.RED);
    }    
    
    // Turn on grid lines using argument color (useful for debugging)
    protected void displayGridLines(Color c){
        grid.setLineColor(c);
    }      
    
    // Turn off grid lines
    protected void hideGridLines(){
        grid.setLineColor(null);
    }    
    
    //Sets the background of the game window to the specified image file
    public void displayGameBackground(String backgroundImg){
        grid.setGridBackgroundImage(backgroundImg);        
    }
    
    
    // Remove the background of the game play
    protected void hideGameBackground(){
        grid.setGridBackgroundImage(null);
    }    
    
    
    //Sets the background color of the game window to the specified Color, or 
    //null for no background color
    public void setBackgroundColor(Color backgroundColor){
        grid.setGridBackgroundColor(backgroundColor);    
    }
    
    
    // Take a screenshot of the content of the GameGrid and saves it to a file
    // of the argument filename
    protected void takeScreenShot(String fileName){
        grid.save(fileName);
    }    
    
    
    // Update the title bar of the game window
    protected void updateTitle(String title) {
        grid.setTitle(title);
    }    
    
    
    //--------------------- Grid Methods --------------------   
    
    //Sets the cell at the argument location to display the argument
    //image (passed as a filename).  If null is passed for the image name,
    //makes the cell at the specified location display nothing.
    protected void setGridImage(Location loc, String imgName) {
        grid.setCellImage(loc, imgName);
    }
    
    
    // Return the name of the image stored at the location
    // returns null if the cell is blank.
    protected String getGridImage(Location loc) {
        return grid.getCellImage(loc);
    }
    
    
    // Moves the content from the cell at one location to another.
    //Any image displayed and/or background color will be moved,
    //and the 'from' cell will be blank after the move is completed.
    protected String moveGridImage(Location from, Location to) {
        String img = getGridImage(from);
        String eraseImg = getGridImage(to);
        Color color = getGridColor(from);
        setGridImage(from, null);
        setGridColor(from, null);
        setGridImage(to, img);
        setGridColor(to, color);
        return eraseImg;
    }
    
    // Return the total number of rows of the game board
    protected int getTotalGridRows() {
        return grid.getNumRows();
    }
    
    // Return the total number of columns of the game board
    protected int getTotalGridCols() {
        return grid.getNumCols();
    }
    
    
    //Sets the background color of an individual cell at a specified location
    protected void setGridColor(Location loc, Color color) {
        grid.setColor(loc, color);
    }
    
    //Returns the background color of an individual cell at a specified location
    protected Color getGridColor(Location loc) {
        return grid.getColor(loc);
    }    
    
    
    //-------------------- User Interface Methods ------------------------// 
    
    // Checks the last keyboard key pressed by the user
    // Return the pressed key code or GameGrid.NO_KEY if no key was pressed
    protected int handleKeyPress() {
        int key = grid.checkLastKeyPressed();        
        if (key != GameGrid.NO_KEY)
            System.out.println("Debug print statement #1!");
        return key;
    }    
    
    //---------------------- Private Helper Methods -----------------------//  
    
    
    //the main loop that handles the execution of the game
    private void gameLoop() {
        //Continue looping until the game is over
        //Each iteration of this loop represents one game "tick"
        while (!isGameOver()){            
            this.sleep(currentTimerDelay); 
            
            //Some tasks get performed on every tick of the game loop
            //and some only get performed on "render ticks"... trace the methods!
            performGameUpdates();
            if (isRenderTick())
                performRenderUpdates();
            
            //don't update accumulators if the game is paused
            if (!isPaused){
                msElapsed += currentTimerDelay;
                ticksElapsed++;
            } 
        }   
    }
    
    
    //determines if the current tick is a "render tick" or not...
    private boolean isRenderTick(){
        return (ticksElapsed % factor == 0);
    }
    
    
    
    // Pauses the execution of the code for the argument number of milliseconds
    // essentially makes the program just "sit and wait" for the specified amount
    // of time -- necessary in the game loop!
    private void sleep(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } 
        catch(Exception e) { 
            //shouldn't ever reach here, but try/catch is necessary due to 
            //Java's implementation of Thread.sleep function
        }
    }
    
    
    
    
    
    //Displays a splash screen image covering the entirety of the board, until user presses the argument key to advance.
    //splashImage is file name of image to be displayed
    //splashScreenAdvanceKey is the keyboard key user must press to continue
    protected void runStillScreen(String splashImage, int splashScreenAdvanceKey){
        
        grid.setSplashScreen(splashImage);
        
        while (grid.checkLastKeyPressed() != splashScreenAdvanceKey) {
            //A call to sleep() is necessary here to slow down execution of the 
            //game, otherwise the user's key press won't be recognized!
            sleep(currentTimerDelay);
        }
        
        grid.setSplashScreen(null);
    }
    
    
    
    // Check for MOUSE CLICK in game window
    // Returns the Location of the GameGrid in which the cursor click occured,
    // or null if mouse isn't clicked
    protected Location handleMouseClick() {
        
        Location loc = grid.checkLastLocationClicked();
        
        if (loc != null)
            System.out.println("You clicked on a square " + loc);
        
        return loc;
    }    
    
    //---------------- Abstract methods -----------------//
    //        (to be implemented in the child!)
    
    
    //checks to see if the game is over
    protected abstract boolean isGameOver();
    
    
    //handles all of the tasks done on each tick
    protected abstract void performGameUpdates();
    //handles all of the tasks done only on each "render tick"
    protected abstract void performRenderUpdates();
    
    //contains all of the tasks that need to be done when game starts/ends
    protected abstract void startGame();
    protected abstract void endGame();
    
    
    
    
    
}
