import java.awt.event.KeyEvent;
import java.awt.Color;
import java.util.Random;

//Represents an instance of a single Tetris Game
//is an extension of Game -- builds off the framework (ie. attributes,
//and methods) of Game to make a tetris-style game
public class TetrisGame extends GameCore {
    
    
    //---------------- Class Variables and Constants -----------------//
    
    //filename of splash screen image
    protected static final String INTRO_SPLASH_IMAGE = "tetris_splash.png"; 
    
    //used anytime random numbers are needed
    //USE THIS! Don't create additional Random objects, just reuse this one!
    protected static final Random DICE = new Random();   
    
    //ints representing the change in x for moving left/right
    public static final int LEFT = -1;
    public static final int RIGHT = 1;
    
    //Determines how much the drop speed changes when inc/dec drop speed
    private static final int DROP_SPEED_FACTOR = 4;
    
    //amount of points awarded for clearing 0, 1, 2, 3, and 4 lines
    public static final int[] LINE_CLEAR_POINTS = {0, 40, 100, 300, 1200};
    
    // default number of vertical/horizontal cells: height/width of grid
    //Tetris board is 20 rows by 10 columns
    private static final int DEFAULT_GRID_H = 20;
    private static final int DEFAULT_GRID_W = 10;
    
    //the color completed rows change before they're cleared
    public static final Color COMPLETED_ROW_COLOR = Color.GRAY;
    
    //assignments for the various keyboard controls
    //use Java constant names for key presses
    //http://docs.oracle.com/javase/7/docs/api/constant-values.html#java.awt.event.KeyEvent.VK_DOWN   
    public static final int KEY_QUIT_GAME = KeyEvent.VK_Q;
    public static final int KEY_PAUSE_GAME = KeyEvent.VK_P;    
    public static final int KEY_SPEED_UP_DROP = KeyEvent.VK_DOWN;
    public static final int KEY_SLOW_DOWN_DROP = KeyEvent.VK_UP;
    public static final int KEY_ROTATE_PIECE = KeyEvent.VK_SPACE;
    public static final int KEY_SLIDE_LEFT = KeyEvent.VK_LEFT;
    public static final int KEY_SLIDE_RIGHT = KeyEvent.VK_RIGHT;
    
    
    
    //---------------- Instance Variables -----------------//    
    
    
    //Stores the active (ie, current "falling") tetromino.  If no piece is 
    //actively falling, this is null
    protected Tetromino activePiece;
    
    //The player's current score
    protected int score;
    
    //boolean determining if the game is over
    //game ends when board is filled and there's no space to generate next piece
    private boolean isGameOver = false;
    
    
    
    
    //---------------- Constructors -----------------//
    
    //uses default grid dimensions and speed (see 3 arg constructor)
    public TetrisGame() {
        this(DEFAULT_GRID_H, DEFAULT_GRID_W);
    }
    
    
    //uses provided grid dimensions and default speed (see 3 arg)
    public TetrisGame(int grid_h, int grid_w){
        this(grid_h, grid_w, DEFAULT_TIMER_DELAY);
    }
    
    
    //Creates game with provided grid dimensions and speed.
    //hdim/wdim: determines number of rows/columns on board, respectively
    //timerDelay: determines initial speed of game -- time between "ticks" (see game loop code for more)
    public TetrisGame(int hdim, int wdim, int timerDelay) {
        //Parent class initializes the basic game properties 
        //ex: the dimensions of game board, the game speed, etc
        super(hdim, wdim, timerDelay);
        
        //Initialize the TetrisGame-specific properties here
        super.displayGridLines(Color.BLACK); //draws black grid lines between blocks
        updateTitle(); //initializes title bar
    }
    
    
    
    
    //---------------- Instance Methods -----------------//
    
    //contains all of the tasks that need to be done each time a game is
    //started or reset
    protected void startGame(){
        this.score = 0; //reset score
        this.activePiece = null; //make sure there is no actively falling piece
        
        //displays the introduction screen until user presses enter
        //See parent class method for more info
        super.displayStillScreen(INTRO_SPLASH_IMAGE);
    }
    
    
    //contains all of the tasks that need to be done each time a game ends
    protected void endGame(){
        updateTitle("GAME OVER | Score: " + getScore());
    }
    
    
    //Contains tasks that must be done on each game tick
    protected void performGameUpdates() {
        //reacts to any user inputs since the last tick       
        handleKeyPress();
        highlightCompletedRows();
        //updates the window title (ie, the current game score)
        updateTitle();
        
    }
    
    
    //Executes tasks that are only done on "render ticks"
    protected void performRenderUpdates(){
        animateGameBoard();
    }
    
    
    //Performs animations on the game board, such as making pieces fall and 
    //clearing completed rows.
    private void animateGameBoard(){
        //Scenario #1
        if (isPaused)
            return;  //nothing for us to do here           
        //Scenario #2
        else if (activePiece == null){          
            spawnNextTetromino(); //generates a new active (ie "falling") piece
        }
        //Scenario #3
        else if (isDoneFalling(activePiece)){
            activePiece = null;
            currentTimerDelay = defaultTimerDelay; //reset piece fall speed to default
        }
        //Scenario #4
        else {
            eraseCompletedRows();
            eraseTetromino(activePiece);
            activePiece.dropOneRow(); 
            drawTetromino(activePiece);
        }                
    }
    
    
    //Erase any completed lines, and updates the score accordingly
    private void eraseCompletedRows() {
        
        int rows = super.getTotalGridRows();
        int cols = super.getTotalGridCols();
        int rowsCleared = 0;
        for (int row = rows-1; row >=0; row--){     
            Location check = new Location(row, 0);
            //Completed rows have already been highlighted gray
            //so check the first cell in the row
            if (super.getGridColor(check) == COMPLETED_ROW_COLOR){                
                rowsCleared++; 
                //we found a completed row, so we need to clear it!
                super.setGridColor(check, null);
                for (int col = 0; col < cols; col++){
                    check = new Location(row, col);
                    super.setGridColor(check, null);
                }
            }
            else if (rowsCleared > 0) {
                //otherwise, if its not a completed row, we need to drop it
                //(if any rows were previously cleared below it!)
                for (int r = row; r >= 0; r--){
                    dropEntireRow(r, rowsCleared);
                }
                rowsCleared = 0;
            }
        }
    }
    
    
    //Drops all cells in the argument row number by the argument number
    //of rows
    private void dropEntireRow(int row, int rowsToDrop){
        
        for (int col = 0; col < super.getTotalGridCols(); col++){
            Location oldCell = new Location(row, col);
            Location newCell = new Location(row + rowsToDrop, col);
            super.setGridColor(newCell, super.getGridColor(oldCell));
            super.setGridColor(oldCell, null);
        }
        
    }
    
    
    
    //Highlight any completed rows gray
    private void highlightCompletedRows() {
        int rows = super.getTotalGridRows();
        int cols = super.getTotalGridCols();
        //for each row, determine if it is full
        for (int row = 0; row < rows; row++){
            boolean isFull = true;
            for (int col = 0; col < cols; col++){
                Location check = new Location(row, col);
                if (super.getGridColor(check) == null){
                    isFull = false;
                    break;
                }
            }
            if (isFull){
                //if it is full, change the colors of all of its blocks to gray
                for (int col = 0; col < DEFAULT_GRID_W; col++){
                    Location check = new Location(row, col);
                    super.setGridColor(check, COMPLETED_ROW_COLOR);
                }
            }
        }
    }
    
    //erases the argument Tetromino piece from the game grid
    private void eraseTetromino(Tetromino toErase){
        // determine the current placement of the piece on the grid
        // by looking at the location of the bottom-left corner of the piece
        Location toEraseCornerLoc = toErase.getBottomLeftLoc();
        int originRow = toEraseCornerLoc.getRow();
        int originCol = toEraseCornerLoc.getCol();
        int[][] points = toErase.getPoints();
        
        //erase every cell of each of the piece's blocks from the grid
        for (int i = 0; i < points.length; i++){
            Location toColor = new Location(originRow - points[i][0], originCol + points[i][1]);
            super.setGridColor(toColor, null);
        }        
    }
    
    //paints the argument Tetromino piece to the game grid
    private void drawTetromino(Tetromino toDraw){
        // determine the current placement of the piece on the grid
        // by looking at the location of the bottom-left corner of the piece
        Location toDrawCornerLoc = toDraw.getBottomLeftLoc();
        int originRow = toDrawCornerLoc.getRow();
        int originCol = toDrawCornerLoc.getCol();
        int[][] points = toDraw.getPoints();
        
        //color in the appropriate cells of the grid based on the piece's color
        for (int i = 0; i < points.length; i++){
            Location toColor = new Location(originRow - points[i][0], originCol + points[i][1]);
            super.setGridColor(toColor, toDraw.getPieceColor());
        }                
    }
    
    
    //Generates a new active (or "falling") tetromino piece at top of game board
    private void spawnNextTetromino(){
        
        activePiece = instantiateRandomTetromino();
        
        //center the piece on the board (taking into account piece's width)
        int startingCol = super.getTotalGridCols()/2 - (activePiece.getWidth()/2);
        
        //make sure piece fits on the board
        int startingRow = activePiece.getHeight()-1;
        activePiece.setBottomLeftLoc(new Location(startingRow, startingCol));
        
        //if piece spawns ontop of another piece, board is filled and its a GameOver
        if (!arePointsSafe(activePiece.getPoints(), activePiece.getBottomLeftLoc()))
            isGameOver = true;
        
        drawTetromino(activePiece);
    }
    
    
    //reacts to user's keyboard input as the game is being played
    protected int handleKeyPress() {
        
        int key = super.handleKeyPress();
        if (key != GameGrid.NO_KEY)
            System.out.println("Debug print statement #2!");
        
        //figure out which key was pressed and react accordingly (if necessary)
        if (key == KEY_PAUSE_GAME)
            isPaused = !isPaused; 
        else if (key == KEY_QUIT_GAME)
            System.exit(0);  //kill the program        
        else if (key == KEY_SPEED_UP_DROP)
            currentTimerDelay = defaultTimerDelay / DROP_SPEED_FACTOR;
        else if (key == KEY_SLOW_DOWN_DROP)
            currentTimerDelay = defaultTimerDelay;
        else if (activePiece != null && isPaused == false){
            if (key == KEY_ROTATE_PIECE){
                eraseTetromino(activePiece);                
                if (isSafeToRotate(activePiece))
                    activePiece.rotate();
                drawTetromino(activePiece);
            }
            else if (key == KEY_SLIDE_LEFT){
                eraseTetromino(activePiece);
                if (isSafeToSlide(activePiece, LEFT))
                    activePiece.slide(LEFT);
                drawTetromino(activePiece);    
            }
            else if (key == KEY_SLIDE_RIGHT){
                eraseTetromino(activePiece);
                if (isSafeToSlide(activePiece, RIGHT))
                    activePiece.slide(RIGHT);
                drawTetromino(activePiece); 
            }                
        }
        
        return key;
    }
    
    
    
    //Checks if the cells at the provided coordinates are "safe"
    //Cells are safe if there is no collision and are not out of bounds
    //Can optionally provide points offset by a bottom left location
    public boolean arePointsSafe(int[][] points){
        return arePointsSafe(points, new Location(0,0));        
    }
    
    public boolean arePointsSafe(int[][] points, Location bottomLeftLoc){        
        int originRow = bottomLeftLoc.getRow();
        int originCol = bottomLeftLoc.getCol();
        
        for (int i = 0; i < points.length; i++){
            Location checkCollision = new Location(originRow - points[i][0], originCol + points[i][1]);
            //if point is outside bounds of window
            if (checkCollision.getRow() < 0 || checkCollision.getRow() >= super.getTotalGridRows())
                return false;            
            if (checkCollision.getCol() < 0 || checkCollision.getCol() >= super.getTotalGridCols())
                return false;
            //if point is ontop of another block
            if (super.getGridColor(checkCollision) != null)
                return false;
        }
        return true;
    }
    
    
    
    //Checks to see if the argument termonio is done falling -- in other words, 
    //whether any of its blocks has collided has landed ontop of another piece
    //or the bottom of the well
    public boolean isDoneFalling(Tetromino fallingPiece){
        // determine the current placement of the piece on the grid
        // by looking at the location of the bottom-left corner of the piece
        Location fallingPieceCornerLoc = fallingPiece.getBottomLeftLoc();
        int originRow = fallingPieceCornerLoc.getRow();
        int originCol = fallingPieceCornerLoc.getCol();
        
        //get the piece's "skirt" (coordinate data of the bottommost pieces,
        //useful in determining collisions)
        int[] skirt = fallingPiece.getSkirt();
        for (int i = 0; i < skirt.length; i++){
            if (originRow - skirt[i] +1 >= super.getTotalGridRows())
                return true;
            Location toCheck = new Location(originRow - skirt[i] + 1, originCol + i);
            if (super.getGridColor(toCheck) != null)
                return true;
        }
        return false;
    }
    
    
    //Checks if the argument Tetromino is safe to slide left or right,
    //meaning if there are no collisions and no blocks are out of bounds
    private boolean isSafeToSlide(Tetromino piece, int dir){       
        System.out.println("calling isSafeToSlide, dir = " + dir);
        Location currentBottomLeftLoc = piece.getBottomLeftLoc();
        int currentRow = currentBottomLeftLoc.getRow();
        int currentCol = currentBottomLeftLoc.getCol();
        //creates a location that is one cell to the left or right (depending on
        //direction moving) of where the active teromino currently is.
        Location newBottomLeftLoc = new Location(currentRow, currentCol-1);
        Location newBottomRightLoc = new Location(currentRow, currentCol+1);
        if (dir == -1){
            return arePointsSafe(piece.getPoints(), newBottomLeftLoc);
        }
        else{
            return arePointsSafe(piece.getPoints(), newBottomRightLoc);
        }
       
    }
    
    
    //Checks if cells are safe to rotate argument Tetromino to next rotation
    //Cells are safe if there is no collision and are not out of bounds    
    private boolean isSafeToRotate(Tetromino piece){
        int[][] points = piece.getNextRotationPoints();
        Location bottomLeftLoc = piece.getBottomLeftLoc();
        return arePointsSafe(points, bottomLeftLoc);
    }
    
    
    //return the score of the game 
    private int getScore() {
        return score; 
    }
    
    
    
    //updates the title bar of the game window 
    private void updateTitle() {
        super.updateTitle("Tetris | Score:  " + getScore());
    }
    
    
    // return true if the game is finished, false otherwise
    protected boolean isGameOver() {
        return isGameOver;
    }
    
    
    
    
    //---------------- Class/Helper Functions -----------------// 
    
    
    //Instantiates and returns a random Tetromino piece
    private static Tetromino instantiateRandomTetromino(){
        int roll = DICE.nextInt(Tetromino.ALL_SHAPES.length);    
        switch (roll){
            case (Tetromino.SQUARE_SHAPE):
                return new ShapeSquare();
            case (Tetromino.STICK_SHAPE):
                return new ShapeStick();
            case (Tetromino.PERISCOPE_L_SHAPE):
                return new ShapePeriscopeL();
            case (Tetromino.PERISCOPE_R_SHAPE):
                return new ShapePeriscopeR();
            case (Tetromino.DOG_L_SHAPE):
                return new ShapeDogL();
            case (Tetromino.T_SHAPE):
                return new ShapeT();                       
            default:
                return new ShapeDogR();            
        }
        
    }  
    
}
